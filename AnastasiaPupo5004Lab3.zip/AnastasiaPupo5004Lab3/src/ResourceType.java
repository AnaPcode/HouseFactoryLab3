/**
 * Enum consisting of resource types that can be used.
 */
public enum ResourceType {STONE, WOOD, HOUSE}
